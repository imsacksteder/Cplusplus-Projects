#ifndef SONGLIST_H
#define SONGLIST_H

//array size constant
const int MAX_CHAR = 101; 

//create Song datatype
struct Song
{
    //give song attributes
    char title[MAX_CHAR];
    char artist[MAX_CHAR];
    char album[MAX_CHAR];
    int min;
    int sec;
};

//create array wrap-around class
class SongList
{

private:
    //array of structs (songlist)
    Song songlist[MAX_CHAR];

public:
    //consructor
    SongList();

    //array functions
    void addSong(const Song& aSong, int& size);
    void listAll(int size);
    void rmSong(int index, int& size);
    void search(char artistName[], int size);
    void loadSongs(int& size, const char filename[]); //from external data file
    void saveSongs(int size, const char filename[]); //to external data file

    //for song struct
    void readInSong(Song& thisSong);
    void readInArtist(char artistName[]);
    void readInIndex(int& index, int size);
    void printSong(const Song& aSong, int index);
    
    //data validation
    char getChar();
    int getInt();
    void getString(char str[], int maxChar);
};

#endif



