#include <iostream>
#include <fstream>
#include <cstring>
#include "SongList.h"

using namespace std;

/* CLASS FUNCTION IMPLEMENTATION */

//Default Constructor:
// initialize a newly created SongList object
SongList::SongList() {
    char filename[] = "songs.txt";
    Song songlist[MAX_CHAR];
    int size = 0;
}

/* FILE STREAM FUNCTIONS */
//these functions deal with file input and output

//Load in songs: format consistent with "songlist.txt"
void SongList::loadSongs(int& size, const char filename[]) {
    
    //use ifstream object to open file
    std::ifstream in;
    
    //variables to copy in song info
    char title[MAX_CHAR];
    char artist[MAX_CHAR];
    char album[MAX_CHAR];
    int min;
    int sec;
    Song thisSong;

    in.open(filename);
    
    //protect against failed input
    if(!in) {
        cerr << "File input failed. Cannot read :" << filename << endl;
        exit(1); //abort program
    }

    in.get(title, MAX_CHAR, ';'); //read in first title
    while(!in.eof()) //until end of file
    {
        //read in each song attribute
        in.get(); //remove delimiter char (;)
        in >> min; 

        in.get();
        in >> sec;

        in.get();
        in.get(artist, MAX_CHAR, ';');

        in.get();
        in.get(album, MAX_CHAR, '\n');
        in.ignore(MAX_CHAR, '\n'); //remove '\n'

        //copy song attributes to struct object
        strcpy(thisSong.title, title); 
        thisSong.min = min;
        thisSong.sec = sec;
        strcpy(thisSong.artist, artist);
        strcpy(thisSong.album, album);
       
        ///add each song to the array (SongList class instance)
        SongList::addSong(thisSong, size);

        in.get(title, MAX_CHAR, ';'); //start next iteration
    }
    in.close();
}

//save to .txt file
void SongList::saveSongs(int size, const char filename[]) { 
    ofstream out; 
    out.open(filename); 
    if(!out) { 
        cerr << "File output failed. Cannot write to: " << filename << endl; 
        exit(1); 
    } 
    
    //write songs to .txt file with delimeter ";"
    for(int i=0; i<size; i++) { 
        out << songlist[i].title << ";" 
        << songlist[i].min << ";" 
        << songlist[i].sec << ";" 
        << songlist[i].artist << ";" 
        << songlist[i].album << endl; 
    } 
    out.close(); 
};


/* ARRAY FUNCTIONS */
//these functions manitpulate the array songlist[]

//add Song struct to songlist
void SongList::addSong(const Song& aSong, int& size) {
    songlist[size] = aSong;
    size++;
}


//print all songs with information and indices
void SongList::listAll(int size) {
    for(int i=0; i<size; i++) {
        printSong(songlist[i], i+1);
    }
}

//search by artist
void SongList::search(char artistName[], int size) {
    bool found = false;
    for(int i=0; i<size; i++) {
        if( strcmp(artistName, songlist[i].artist) == 0 ) { //compare char arrays
            printSong(songlist[i], i+1);
            found = true;
        }
    }
    if(!found) {
      cout << "No matching artist (input is case sensitive)";
    }
}

//remove a song
void SongList::rmSong(int index, int& size) {

    //make an array copy for reference
    Song arrCopy[size];
    for(int i = 0; i<size; i++) { //populate the copy
        arrCopy[i] = songlist[i];
    }

    //shift songs down
    for(int i=index-1; i<size; i++) {
        songlist[i] = arrCopy[i+1];
    }

    //update the size counter
    size--;
}


/* SONG STRUCT FUNCTIONS */
//these function use the Song struct, but  do not access songlist[]

//read in a new song
void SongList::readInSong(Song& thisSong) {
    //song title
    cout << "Enter Song title: ";
    getString(thisSong.title, MAX_CHAR);

    //duration
    cout << "Please enter song duration (minutes): ";
    thisSong.min = getInt();
    cout << "Please enter song duration (seconds): ";
    thisSong.sec = getInt();

    //additional info
    cout << "Enter Artist: ";
    getString(thisSong.artist, MAX_CHAR);
    cout << "Enter Album: ";
    getString(thisSong.album, MAX_CHAR);
}

//read in artist for search
void SongList::readInArtist(char artistName[]) {
    cout << "Enter Artist Name: ";
    getString(artistName, MAX_CHAR);
}

//read in index for remove 
void SongList::readInIndex(int& index, int size) {
    cout << "Enter index of song you would like to delete: ";
    index = getInt();

    //index too big?
    if(index > size) {
        cout << "Index out of bounds. ";
        readInIndex(index, size);
    }

    //index too small?
    if(index < 1) {
        cout << "Index out of bounds. ";
        readInIndex(index, size);
    }
}

//print all information for one song
void SongList::printSong(const Song& aSong, int index) {
      
    char secDisplay[MAX_CHAR] = "";
    if (aSong.sec < 10) {
        strcpy(secDisplay, "0");
    } 
    
    cout << index << ". " <<  aSong.title
        << ", Duration: " << aSong.min << "." << secDisplay << aSong.sec
        << ", Artist: " << aSong.artist
        << ", Album: " << aSong.album << endl;
}


/* DATA VALIDATION */
//input utility functions

int SongList::getInt() {
    int num;
    cin >> num;
    
    //check for type error
    while(!cin) {
        cin.clear();
        cin.ignore(MAX_CHAR, '\n');
        cout << "Illegal Input. Enter an Integer: ";
        getInt();
    }
    cin.ignore(MAX_CHAR, '\n');
        
    //check for negative input
    if(num < 0) {
        cout << "Please enter a positive integer: ";
        getInt();
    }
    return num;
}

char SongList::getChar() {
    char letter;

    cin >> letter;
    while(!cin) {
        cin.clear();
        cin.ignore(MAX_CHAR, '\n');
        cout << "Illegal Input. Enter a Char: ";
        cin >> letter;
    }
    cin.ignore(MAX_CHAR, '\n');
    return letter;
}

void SongList::getString(char str[], int maxChar) {
    cin.get(str, maxChar, '\n');
    while(!cin) {
        cin.clear();
        cin.ignore(maxChar, '\n');
        cout << "Illegal Input. Enter a String: ";
        cin.get(str, maxChar, '\n');
    }
    cin.ignore(MAX_CHAR, '\n');
}
