/* Isabel Sacksteder
CS 162 31145
07/20/20
Sources:  1. LearnCpp.com (Class code and header files)
          https://www.learncpp.com/cpp-tutorial/89-class-code-and-header-files/           

          2. cplusplus.com (Classes I)
          http://www.cplusplus.com/doc/tutorial/classes/

          3. lab4 (Makefile Syntax)
          ~adam.cornachione/ac162/labs/lab4

This program employs a class to model a songlist. With a looping user interface for input, 
it reads and writes to a text file (songs.txt) with information about songs from a library */

#include <iostream>
#include <fstream>
#include <cstring>
#include "SongList.h"

using namespace std;

//UI prototypes
void start();
void displayMenu();
char readInCommand(SongList songlist);
void executeCommand(char command, SongList& songlist, int& size);

int main()
{
    //start looping user interface (see ui)
    start();
    return 0;
}

/* USER INTERFACE */
void start()
{
    char command;
    SongList songlist;
    int size = 0;
    char filename[] = "songs.txt";     

    //read in file when program starts
    songlist.loadSongs(size, filename);

    //display navigation menu
    displayMenu();
    command = readInCommand(songlist); //command input

    while(command != 'q') //q causes program to quit, return to menu
    {
        executeCommand(command, songlist, size);
        displayMenu();
        command = readInCommand(songlist);
    }

    //before exiting the program, write changes to file
    songlist.saveSongs(size, filename);
}

//print menu options
void displayMenu() {
    cout << endl << "Song Library Menu:" << endl
        << "    a. Add a song entry" << endl
        << "    l. List all song entries" << endl
        << "    s. Search by artist" << endl
        << "    r. Remove an entry by index" << endl
        << "    q. Quit " << endl;
}

//command input
char readInCommand(SongList songlist) {
 
    cout << "please enter the command (a, l, s, r, or q): ";
    char cmd = songlist.getChar();
    return tolower(cmd);
}

//switch structure for various commmand selections
void executeCommand(char cmd, SongList& songlist, int& size) {

    Song thisSong; //struct data type
    char artistName[MAX_CHAR];
    int index;

    switch(cmd) {
        case 'a':
            songlist.readInSong(thisSong);
            songlist.addSong(thisSong, size); //add to array of structs
            break;
        case 'l':
            songlist.listAll(size); //list all songs
            break;
        case 's':
            songlist.readInArtist(artistName);
            songlist.search(artistName, size); //search artist
            break;
        case 'r':
            songlist.readInIndex(index, size);
            songlist.rmSong(index, size); //remove song
            cout << "Illegal command" << endl;
            break;
    }

}
