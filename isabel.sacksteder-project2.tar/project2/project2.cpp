/* Isabel Sacksteder
CS 162 31145
06/06/20
Sources:  1. Stack Overflow (Comparing the values of char arrays in C++)
          https://stackoverflow.com/questions/15050766/comparing-the-values-of-char-arrays-in-c

          2. cplusplus.com (copying an array into another)
          http://cplusplus.com/forum/general/199358/

          3. CodingUnit.com (c++ arrays, arrays and loops)
          https://www.codingunit.com/cplusplus-tutorial-arrays-arrays-and-loops

          4. Video Lecture 3 (Desire2Learn)

This program reads and writes to a text file (songs.txt) with information
about songs from a library, complete with a looping user interface */

#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

//array size constant
const int MAX_CHAR = 101;

//create Song datatype
struct Song
{
    //give song attributes
    char title[MAX_CHAR];
    char artist[MAX_CHAR];
    char album[MAX_CHAR];
    int min;
    int sec;
};

//UI prototypes
void start();
void displayMenu();
char readInCommand();
void executeCommand(char command, Song list[], int& size);

//Song struct prototypes
void readInSong(Song& aSong);
void readInArtist(char artistName[]);
void readInIndex(int& index, int size);
void printSong(const Song& aSong);

//utility prototypes
char getChar();
int getInt();
void getString(char str[], int maxChar);

//database prototypes
void addSong(const Song& aSong, Song list[], int& size);
void listAll(const Song list[], int size);
void rmSong(int index, Song list[], int& size);
void search(char artistName[], Song list[], int size);
void loadSongs(Song list[], int& size, const char filename[]); //from external data file
void saveSongs(const Song list[], int size, const char filename[]); //to external data file

int main()
{
    //start looping user interface (see ui)
    start();
    return 0;
}

/* USER INTERFACE */
void start()
{
    char command;
    Song songlist[MAX_CHAR];
    int size =0;
    char filename[] = "songs.txt";

    //read in file when program starts
    loadSongs(songlist, size, filename);

    //display navigation menu
    displayMenu();
    command = readInCommand(); //command input

    while(command != 'q') //q causes program to quit, return to menu
    {
        executeCommand(command, songlist, size);
        displayMenu();
        command = readInCommand();
    }

    //before exiting the program, write changes to file
    saveSongs(songlist, size, filename);
}

//print menu options
void displayMenu() {
    cout << endl << "Song Library Menu:" << endl
        << "    a. Add a song entry" << endl
        << "    l. List all song entries" << endl
        << "    s. Search by artist" << endl
        << "    r. Remove an entry by index" << endl
        << "    q. Quit " << endl;
}

//command input
char readInCommand() {
    cout << "please enter the command (a, l, s, r, or q): ";
    char cmd = getChar();
    return tolower(cmd);
}

//switch structure for various commmand selections
void executeCommand(char cmd, Song list[], int&size) {

    Song thisSong; //struct data type
    char artistName[MAX_CHAR];
    int index;

    switch(cmd) {
        case 'a':
            readInSong(thisSong);
            addSong(thisSong, list, size); //add to array of structs
            break;
        case 'l':
            listAll(list, size);
            break;
        case 's':
            readInArtist(artistName);
            search(artistName, list, size);
            break;
        case 'r':
            readInIndex(index, size);
            rmSong(index, list, size);
            break;
        default:
            cout << "Illegal command" << endl;
            break;
    }

}

/* BACKEND / DATABASE FUNCTIONS */

void readInSong(Song& thisSong)
{
    //song title
    cout << "Enter Song title: ";
    getString(thisSong.title, MAX_CHAR);

    //duration
    cout << "Please enter song duration (minutes): ";
    thisSong.min = getInt();
    cout << "Please enter song duration (seconds): ";
    thisSong.sec = getInt();

    //additional info
    cout << "Enter Artist: ";
    getString(thisSong.artist, MAX_CHAR);
    cout << "Enter Album: ";
    getString(thisSong.album, MAX_CHAR);
}

void readInArtist(char artistName[]) {
    cout << "Enter Artist Name: ";
    getString(artistName, MAX_CHAR);
}

void readInIndex(int& index, int size) {
    cout << "Enter index of song you would like to delete: ";
    index = getInt();

    //index too big?
    if(index > size) {
        cout << "Index out of bounds. ";
        readInIndex(index, size);
    }

    //index too small?
    if(index < 1) {
        cout << "Index out of bounds. ";
        readInIndex(index, size);
    }

}

//print all information for one song
void printSong(const Song& aSong, int index) {
    cout << index << ". " <<  aSong.title
        << ", Duration: " << aSong.min << "." << aSong.sec
        << ", Artist: " << aSong.artist
        << ", Album: " << aSong.album << endl;
}

//add a song to array of structs
void addSong(const Song& aSong, Song list[], int& size) {
    list[size] = aSong;
    size++;
}

//print all songs with information and indices
void listAll(const Song list[], int size) {
    for(int i=0; i<size; i++) {
        printSong(list[i], i+1);
    }
}

//search by artist
void search(char artistName[], Song list[], int size) {
    bool found = false;
    for(int i=0; i<size; i++) {
        if( strcmp(artistName,list[i].artist) == 0 ) { //compare char arrays
            printSong(list[i], i+1);
            found = true;
        }
    }
    if(!found) {
      cout << "No matching artist (input is case sensitive)";
    }
}

void rmSong(int index, Song list[], int& size) {

    //make an array copy for reference
    Song arrCopy[size];
    for(int i = 0; i<size; i++) { //populate the copy
        arrCopy[i] = list[i];
    }

    //shift songs down
    for(int i=index-1; i<size; i++) {
        list[i] = arrCopy[i+1];
    }

    //update the size counter
    size--;
}

//(format consistent with sonlist.txt)
void loadSongs(Song list[], int& size, const char filename[]) {
    ifstream in;
    char title[MAX_CHAR];
    char artist[MAX_CHAR];
    char album[MAX_CHAR];

    int min;
    int sec;
    Song thisSong;

    in.open(filename);
    //protect against failed input
    if(!in) {

        cerr << "File input failed. Cannot read :" << filename << endl;
        //error message will go to prefered location
        exit(1); //abort program
    }

    in.get(title, MAX_CHAR, ';'); //read in first title
    while(!in.eof()) //until end of file
    {
        in.get(); //remove delimiter char (;)
        in >> min;

        in.get();
        in >> sec;

        in.get();
        in.get(artist, MAX_CHAR, ';');

        in.get();
        in.get(album, MAX_CHAR, '\n');
        in.ignore(MAX_CHAR, '\n'); //remove '\n'

        strcpy(thisSong.title, title); //copy song object
        thisSong.min = min;
        thisSong.sec = sec;
        strcpy(thisSong.artist, artist);
        strcpy(thisSong.album, album);

        addSong(thisSong, list, size);

        in.get(title, MAX_CHAR, ';'); //start next iteration
    }
    in.close();
}

void saveSongs(const Song list[], int size, const char filename[]) {
    ofstream out;
    out.open(filename);
    if(!out) {
        cerr << "File output failed. Cannot write to: " << filename << endl;
        exit(1);
    }

    for(int i=0; i<size; i++) {
        out << list[i].title << ";"
        << list[i].min << ";"
        << list[i].sec << ";"
        << list[i].artist << ";"
        << list[i].album << endl;
    }
    out.close();
}


/* UTILITY FUNCTIONS / Data Validation */
int getInt() {
        int num;
        cin >> num;
        while(!cin) {
                cin.clear();
                cin.ignore(MAX_CHAR, '\n');
                cout << "Illegal Input. Enter an Integer: ";
                cin >> num;
        }
        cin.ignore(MAX_CHAR, '\n');
        return num;
}

char getChar() {
        char letter;

        cin >> letter;
        while(!cin) {
                cin.clear();
                cin.ignore(MAX_CHAR, '\n');
                cout << "Illegal Input. Enter a Char: ";
                cin >> letter;
        }
        cin.ignore(MAX_CHAR, '\n');
        return letter;
}

void getString(char str[], int maxChar) {
        cin.get(str, maxChar, '\n');
        while(!cin) {
                cin.clear();
                cin.ignore(maxChar, '\n');
                cout << "Illegal Input. Enter a String: ";
                cin.get(str, maxChar, '\n');
        }
        cin.ignore(MAX_CHAR, '\n');
}
