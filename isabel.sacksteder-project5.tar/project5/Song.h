#ifndef SONG_H
#define SONG_H
 
//Song class just holds data (see Songlist class for playlist management functions)
class Song
{
    private:        
        //give song attributes
        char * title;
        char * artist;
        char * album;
        int min;
        int sec;

    public:
        Song();
//	Song(char origTitle[], char origArtist[], char origAlbum[], int origMin, int origSec);
        ~Song();
        
        //GETTERS
        //these functions have parameter to write to (allows us to "return" an array)
	void getTitle(char  outTitle[]);
        void getArtist(char outArtist[]);
	void getAlbum(char  outAlbum[]);
	
        //getter functions for simple data type (returns int type)
	int getMin();
	int getSec();

        //SETTERS
	void setTitle(char  inTitle[]);
	void setArtist(char  inArtist[]);
	void setAlbum(char  inAlbum[]);
	void setMin(int setMin);
	void setSec(int setSec);

};

#endif
