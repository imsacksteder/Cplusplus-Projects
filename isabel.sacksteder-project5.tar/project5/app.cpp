/* Isabel Sacksteder
CS 162 31145
08/19/20
Project 4
Sources:  1. Epitech 2020 - Technical Documentation (Debug : Understanding Valgrind’s messages)
          https://epitech-2022-technical-documentation.readthedocs.io/en/latest/valgrind.html

          2. cplusplus.com (Double free or corruption error)
          http://www.cplusplus.com/forum/general/29640/

          3. LearnCpp.com (Class code and header files)
          https://www.learncpp.com/cpp-tutorial/89-class-code-and-header-files/           

          4. cplusplus.com (Classes I)
          http://www.cplusplus.com/doc/tutorial/classes/

          5. lab4 (Makefile Syntax)
          ~adam.cornachione/ac162/labs/lab4

          6. cplusplus.com (strcmp)
          http://www.cplusplus.com/reference/cstring/strcmp/ 

This program employs a Linked List class to model a songlist and a seperate class to model each 
Song. Array type song data and the songlist itself are modelled with dynamic arrays (pointers).
With a looping user interface for input, the program reads and writes to a text file (songs.txt) 
with information about songs from a library */

#include <iostream>
#include <fstream>
#include <cstring>
#include "SongList.h"

using namespace std;

//UI prototypes
void start();
void displayMenu();
char readInCommand();
void executeCommand(char command, SongList& songlist, int& size);

//util. function
char gettingChar();

int main()
{
    //start looping user interface (see ui)
    start();
    return 0;
}

/* USER INTERFACE */
void start()
{
    char command;
    SongList songlistObj;
    int size = 0;
    char filename[] = "songs.txt";    

    //read in file when program starts
    songlistObj.loadSongs(size, filename);

    //display navigation menu
    displayMenu();
    command = readInCommand();//command input

    while(command != 'q') //q causes program to quit, return to menu
    {
        executeCommand(command, songlistObj, size);
        displayMenu();
        command = readInCommand();
    }
    //before exiting the program, write changes to file
    songlistObj.saveSongs(size, filename);    
}


//print menu options
void displayMenu() {
    cout << endl << "Song Library Menu:" << endl
        << "    a. Add a song entry" << endl
        << "    l. List all song entries" << endl
        << "    s. Search by artist" << endl
        << "    b. Search by album" << endl
        << "    r. Remove an entry by index" << endl
        << "    q. Quit " << endl << endl;
}

//command input
char readInCommand() {
   
    //prompt user input 
    cout << "please enter the command (a, l, s, b, r, or q): ";
    char cmd = gettingChar(); 

    return tolower(cmd);
}

//switch structure for various commmand selections
void executeCommand(char cmd, SongList& songlistObj, int& size) {

    char albumName[MAX_CHAR];
    char artistName[MAX_CHAR];
    int index = 0;
    
    switch(cmd) {
        case 'a':{
            Node * thisNode = new Node;
            songlistObj.readInSong(thisNode);
            songlistObj.addSong(thisNode, size); //add to array of structs
            break;
        }
        case 'l':
            songlistObj.listAll(size); //list all songs
            break;
        case 's':
            songlistObj.readInArtist(artistName);
            songlistObj.searchByArtist(artistName); //search artist
            break;
        case 'b':
            songlistObj.readInAlbum(albumName);
            songlistObj.searchByAlbum(albumName);
            break;
        case 'r':
            songlistObj.readInIndex(index, size);
            songlistObj.rmSong(index, size); //remove song
            break;
    }

}

//duplicate function from SongList class 
//to read in command without creating SongList object
char gettingChar() {
    char letter;
    cin >> letter;

    while(!cin) {
        cin.clear();
        cin.ignore(MAX_CHAR, '\n');
        cout << "Illegal Input. Enter a Char: ";
        cin >> letter;
    }
    cin.ignore(MAX_CHAR, '\n');
    return letter;
}

