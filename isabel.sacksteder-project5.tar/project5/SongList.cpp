#include <iostream>
#include <fstream>
#include <cstring>
#include <ctype.h>
#include "Song.h"
#include "SongList.h"

using namespace std;

/* CLASS FUNCTION IMPLEMENTATION */

//default constructor:
//initialize head and tail node, link text file
SongList::SongList() { 
    char filename[] = "songs.txt";
    head = NULL;
    tail = NULL;
}

//destructor (called implicity when class object goes out of scope)
SongList::~SongList() { 
    
    //check if songlist is empty
    if(head != NULL) { 
        Node * thisNode = head;
       
        //traverse list and delete nodes    
        while (thisNode->next != NULL) { 
            Node* bufferNode = thisNode; //buffer ptr
            thisNode = thisNode->next;
	    delete bufferNode;
	}
        delete thisNode; //delete last node
    }
}

/* FILE STREAM FUNCTIONS */
//these functions deal with file input and output

//Load in songs: format consistent with "songlist.txt"
void SongList::loadSongs(int& size, const char filename[]) {
    
    //use ifstream object to open file
    std::ifstream in;
    
    //temp variables to copy in song info 
    char bufferTitle[MAX_CHAR];
    char bufferArtist[MAX_CHAR];
    char bufferAlbum[MAX_CHAR];
    int bufferMin;
    int bufferSec;

    in.open(filename);

    //protect against failed input
    if(!in) {
        cerr << "File input failed. Cannot read :" << filename << endl;
        exit(1); //abort program
    }
    //read in info from file
    in.get(bufferTitle, MAX_CHAR, ';'); //read in first title
    
    while(!in.eof()) { //until end of file     

        //read in each song attribute
        in.get(); //remove delimiter char (;)
        in >> bufferMin; 

        in.get();
        in >> bufferSec;

        in.get();
        in.get(bufferArtist, MAX_CHAR, ';');

        in.get();
        in.get(bufferAlbum, MAX_CHAR, '\n');
        in.ignore(MAX_CHAR, '\n'); //remove '\n'
 
        Node * thisNode = new Node; //adding a new song to the list

        //set song attributes
        (thisNode->song).setTitle(bufferTitle);
        (thisNode->song).setMin(bufferMin);
        (thisNode->song).setSec(bufferSec);
        (thisNode->song).setArtist(bufferArtist);
        (thisNode->song).setAlbum(bufferAlbum);
	
        //add each song to the array (SongList class instance)
        SongList::addSong(thisNode, size);
        
        in.get(bufferTitle, MAX_CHAR, ';'); //start next iteration 
        }
    in.close(); 
}

//save to .txt file
void SongList::saveSongs(int size, const char filename[]) { 
    
    ofstream out; 
    out.open(filename); //link fstream obj to "songs.txt" 
    
    if(!out) { 
        cerr << "File output failed. Cannot write to: " << filename << endl; 
        exit(1); 
    }  

    //Write songs to .txt file with delimeter ";"
    //check if list is empty
    if (head == NULL) {
        cout << "writing empty list to file" << endl;
    
    } else {
        Node * currNode = head;
        
	//traverse the list to the end
        while(currNode != tail) {

            //temp variables for data copy
            char tempTitle[MAX_CHAR];
            char tempArtist[MAX_CHAR];
            char tempAlbum[MAX_CHAR];

            //store char arrays in temp variables
            (currNode->song).getTitle(tempTitle);
            (currNode->song).getArtist(tempArtist); 
            (currNode->song).getAlbum(tempAlbum);

            //write song data to text file
            out << tempTitle << ";" 
            << (currNode->song).getMin() << ";" 
            << (currNode->song).getSec() << ";" 
            << tempArtist << ";" 
            << tempAlbum << endl; 
    
            currNode = currNode->next;
  
        } 
 
        //write last node's data to file
        char tempTitle[MAX_CHAR];
        char tempArtist[MAX_CHAR];
        char tempAlbum[MAX_CHAR];

        (currNode->song).getTitle(tempTitle);
        (currNode->song).getArtist(tempArtist); 
        (currNode->song).getAlbum(tempAlbum);

        out << tempTitle << ";" 
        << (currNode->song).getMin() << ";" 
        << (currNode->song).getSec() << ";" 
        << tempArtist << ";" 
        << tempAlbum << endl; 
    
        out.close(); 
    }
}


/* ARRAY FUNCTIONS */
//these functions manipulate the Linked List  songlist

//add Song struct to songlist
void SongList::addSong(Node*  aNode, int& size){

    if(head == NULL) { //check for empty list
        head = aNode;
        tail = aNode;  //keep track of tail	
        head->prev = NULL;
        tail->next = NULL;
    } else {

        //buffer string for song title
        char thisTitle[MAX_CHAR];
        (aNode->song).getTitle(thisTitle);

        //current node for traversing list
        Node * curr = head;       
        char currTitle[MAX_CHAR]; //buffer string  
        (curr->song).getTitle(currTitle);   

        //make sorting case insensitive 
        char thisTitleLower[strlen(thisTitle)];      
        char currTitleLower[strlen(currTitle)];

        //copy in tolower strings
        for(int i=0; i<strlen(thisTitle); i++) {
            thisTitleLower[i] = tolower(thisTitle[i]);
        } 
        for(int i=0; i<strlen(currTitle); i++) {
            currTitleLower[i] = tolower(currTitle[i]);
        }
 
        //traverse to alphabetical position
	while(curr->next != NULL && strcmp(thisTitleLower, currTitleLower)>0 ) { 
            curr = curr->next; 
            (curr->song).getTitle(currTitle);
        } 
        (curr->song).getTitle(currTitle);

        //adding to head
        if ( curr->prev == NULL) { 
            aNode->next = head;
            head->prev = aNode;
            head = aNode;
            
    
        //adding to tail
        } else if ( curr->next == NULL) {
            aNode->prev = tail;
            tail->next = aNode;
            tail = aNode;           
        
        //adding somewhere in the middle  
        } else if (curr->next != NULL && curr->prev != NULL) {
            Node * prevNode = curr->prev;

            //update links
            aNode->next = curr;
            aNode->prev = curr->prev;
    	    curr->prev = aNode; 
            prevNode->next = aNode;
        }
    }
    size++; //increment size
}



//print all songs with information and indices
void SongList::listAll(int size) {    
    
    //check if list is empty
    if (head == NULL) {
        cout << "list is empty" << endl;
    } else { 
        
        //traverse list
        Node * curr = head;
        int count = 0;
        while (curr != NULL) {
            
            //print each item
            printSong(curr, count); 
            curr = curr->next;
            count++;        
        } 
    } 
}

//search by artist
void SongList::searchByArtist(char artistName[]) {
   
   // curr node and buffer string for list traverse
   Node * curr = head;
   char currArtist[MAX_CHAR];
   (curr->song).getArtist(currArtist);   
   
   //traverse list
   int count = 0;
   while(curr->next != NULL) {
     
        //print songs corresponding to artist search
        if( strcmp(artistName, currArtist) == 0 ) { 
            printSong(curr, count);
        }
        
        //move to next node
        curr = curr->next;
        (curr->song).getArtist(currArtist);
        count++;
    }

    //check last item
    if( strcmp(artistName, currArtist) == 0 ) { 
        printSong(curr, count);
    }
}


//search by album
void SongList::searchByAlbum(char albumName[]) {
   
   //curr node and buffer string for list traverse
   Node * curr = head;
   char currAlbum[MAX_CHAR];
   (curr->song).getAlbum(currAlbum);   

   //traverse list
   int count = 0;
   while(curr->next != NULL) {
       
        //print songs correspinding to album search 
        if( strcmp(albumName, currAlbum) == 0 ) { 
            printSong(curr, count);
        }
        
        //move to next node
        curr = curr->next;
        (curr->song).getAlbum(currAlbum);
        count++;
    }

    //check last item
    if( strcmp(albumName, currAlbum) == 0 ) { 
        printSong(curr, count);
    }
}

//remove a song
void SongList::rmSong(int index, int& size) {

    //check is list is empty
    if (head == NULL) {
        cout << "list is empty" << endl;
    }

    //keep tack of nodes
    Node * curr = head;
    Node * prevNode;
    Node * nextNode;
 
    //travers list until index to be deleted    
    int count = 0;
    while (curr->next != NULL && count < index) {
         
         //move to next node
         prevNode = curr;
         curr = curr->next;
         nextNode = curr->next;
         count++;
    }
 
    //remove from head
    if (curr->prev == NULL) {
       //nextNode->prev = NULL;
       head->next = nextNode->next;
       head = nextNode;
       delete curr;  

    //remove from tail
    } else if (curr->next  == NULL) {
        //prevNode->next = NULL
        tail->prev = prevNode->prev;
	tail = prevNode;
        delete curr;

    //remove from somewhere in the middle
    } else {
        prevNode->next = nextNode;
        nextNode->prev = prevNode;
        delete curr;
    }
 
    //update the size counter
    size--;
}


/* SONG STRUCT FUNCTIONS */
//these function use the Song struct, but  do not manipulate the Linked List

//read in a new song
void SongList::readInSong(Node * thisNode) {

    //temp variables to store input data
    char tempTitle[MAX_CHAR];
    char tempArtist[MAX_CHAR];
    char tempAlbum[MAX_CHAR];
    int tempMin;
    int tempSec;

    //song title
    cout << "Enter Song title: ";
    getString(tempTitle, MAX_CHAR);
    (thisNode->song).setTitle(tempTitle);

    //duration
    cout << "Please enter song duration (minutes): ";
    tempMin = getInt();
    (thisNode->song).setMin(tempMin);

    cout << "Please enter song duration (seconds): ";
    tempSec = getInt();
    (thisNode->song).setSec(tempSec);

    //additional info
    cout << "Enter Artist: ";
    getString(tempArtist, MAX_CHAR);
    (thisNode->song).setArtist(tempArtist);

    cout << "Enter Album: ";
    getString(tempAlbum, MAX_CHAR);
    (thisNode->song).setAlbum(tempAlbum);
}

//read in artist for search
void SongList::readInArtist(char artistName[]) {
    cout << "Enter Artist Name: ";
    getString(artistName, MAX_CHAR);
}



//read in album for search
void SongList::readInAlbum(char albumName[]) {
    cout << "Enter Album Name: ";
    getString(albumName, MAX_CHAR);
}

//read in index for remove 
void SongList::readInIndex(int& index, int size) {
    cout << "size is " << size << endl;
    cout << "Enter index of song you would like to delete: ";
    index = getInt();

    //index too big?
    if(index > size) {
        cout << "Index out of bounds. ";
        readInIndex(index, size);
    }

    //index too small?
    if(index < 0) {
        cout << "Index out of bounds. ";
        readInIndex(index, size);
    }
}

//print all information for one song
void SongList::printSong(Node * aNode, int index) {
 
    //check for empty list
    if(aNode == NULL) {
        cout << "List is empty" << endl;
       
    }  

    //temp variables for data copy
    char tempTitle[MAX_CHAR];
    char tempArtist[MAX_CHAR];
    char tempAlbum[MAX_CHAR];
    
    //get song data
    (aNode->song).getTitle(tempTitle);
    (aNode->song).getArtist(tempArtist);
    (aNode->song).getAlbum(tempAlbum);
    
    //print seconds with leading zero if < 10
    char secDisplay[MAX_CHAR] = "";
    if ((aNode->song).getSec() < 10) {
        strcpy(secDisplay, "0");
    } 
    
    //print song
    cout << index << ". " <<  tempTitle
        << ", Duration: " << (aNode->song).getMin() << "." << secDisplay << (aNode->song).getSec()
        << ", Artist: " << tempArtist
        << ", Album: " << tempAlbum << endl;
}


/* DATA VALIDATION */
//input utility functions

//integer input 
int SongList::getInt() {
    int num;
    cin >> num;
    
    //check for type error
    while(!cin) {
        cin.clear();
        cin.ignore(MAX_CHAR, '\n');
        cout << "Illegal Input. Enter an Integer: ";
        num = getInt(); //recursive call
    }
    cin.ignore(MAX_CHAR, '\n');
        
    //check for negative input
    if(num < 0) {
        cout << "Please enter a positive integer: ";
        num = getInt();
    }
    return num;
}

//character input
char SongList::getChar() {
    char letter;
    cin >> letter;

    //check for type error
    while(!cin) {
        cin.clear();
        cin.ignore(MAX_CHAR, '\n');
        cout << "Illegal Input. Enter a Char: ";
        cin >> letter;
    }
    cin.ignore(MAX_CHAR, '\n');
    return letter;
}

//char array input
void SongList::getString(char str[], int maxChar) {
    cin.get(str, MAX_CHAR, '\n');

    //check for bad string
    while(!cin) {
        cin.clear();
        cin.ignore(maxChar, '\n');
        cout << "Illegal Input. Enter a String: ";
        cin.get(str, maxChar, '\n');
    }
    cin.ignore(MAX_CHAR, '\n');
}
