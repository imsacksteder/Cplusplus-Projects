#include "Song.h"
#include <iostream>
#include <cstring>

using namespace std;

//default constructor
Song::Song(){
    title = NULL;
    artist = NULL;
    album = NULL;
    min = 0;
    sec = 0; 
}

//destructor
Song::~Song(){
    if(title) delete [] title;
    title = NULL;
    if(artist) delete [] artist;
    artist = NULL;
    if(album) delete [] album;
    album = NULL;
}

//GETTERS
//these functions have parameter to write to (allows us to "return" an array)
//gives user direct access to title data member 
void Song::getTitle(char  outTitle[]) {
    //cout << "getTitle invoked" << endl;
    //cout << "being copied to outTitle: " << title << endl;

    strcpy(outTitle, title);
}

void Song::getArtist(char  outArtist[]) {
    strcpy(outArtist, artist);
}

void Song::getAlbum(char  outAlbum[]) {
    strcpy(outAlbum, album);
}
	
//getter functions for simple data type (returns int type)
int Song::getMin() {
    return min;
}

int Song::getSec() {
    return sec;
}

//SETTERS
void Song::setTitle(char  inTitle[]) {
    if(title) delete [] title; //check to see if char array is NULL
    title = new char[strlen(inTitle)+1];
    strcpy(title, inTitle);
}

void Song::setArtist(char  inArtist[]) {
    if(artist) delete [] artist;
    artist = new char[strlen(inArtist)+1];
    strcpy(artist, inArtist);
}

//aggregate op, takes in a char pointer directly 
void Song::setAlbum(char  inAlbum[]) {
    if(album) delete [] album;
     album = new char[strlen(inAlbum)+1]; 
     strcpy(album, inAlbum);
}

//simple data types
void Song::setMin(int inMin) {
    min = inMin;
}

void Song::setSec(int inSec) {
    sec = inSec;
}
