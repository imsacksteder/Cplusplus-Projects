#ifndef SONGLIST_H
#define SONGLIST_H

#include "Song.h"

//maximum char array size constant
const int MAX_CHAR = 101; 

//node struct (inclused song object and ptrts)
struct Node {

Song song; //data
Node * next; //double linked
Node * prev; //double linked
};


//array wrap-around class
class SongList
{

private:
    //dynamic array of structs (songlist)
    //Song * songlist;
    //int size;

    Node * head;
    Node * tail;

public:
    //consructor and destructor
    SongList();
    ~SongList();

    //array functions
    //void addSong( Song& aSong, int& size); 
    void addSong(Node * aNode, int& size); //void printSong(Node * aNode, int index);
    void listAll(int size);
    void rmSong(int index, int& size);
    void searchByArtist(char artistName[]);
    void searchByAlbum(char albumName[]);
    void loadSongs(int& size, const char filename[]); //from external data file
    void saveSongs(int size, const char filename[]); //to external data file

    //for song struct
    //void readInSong(Song& thisSong); 
    void readInSong(Node * thisNode);
    void readInArtist(char artistName[]);
    void readInAlbum(char albumName[]);
    void readInIndex(int& index, int size);
    //void printSong(Song& aSong, int index);
    void printSong(Node * aNode, int index);
    
    //data validation
    char getChar();
    int getInt();
    void getString(char str[], int maxChar);
};

#endif



