#include <iostream>
#include <fstream>
#include <cstring>
#include "Song.h"
#include "SongList.h"

using namespace std;

/* CLASS FUNCTION IMPLEMENTATION */

//default constructor:
//initialize a new SongList object, link text file
SongList::SongList() {
    char filename[] = "songs.txt";
    songlist = new Song[MAX_CHAR]; 
    int size = 0;
}

//destructor (called implicity when class object goes out of scope)
SongList::~SongList() { 
    if(songlist) delete [] songlist;
    songlist = NULL;
}

/* FILE STREAM FUNCTIONS */
//these functions deal with file input and output

//Load in songs: format consistent with "songlist.txt"
void SongList::loadSongs(int& size, const char filename[]) {
    
    //use ifstream object to open file
    std::ifstream in;
    
    //temp variables to copy in song info 
    char bufferTitle[MAX_CHAR];
    char bufferArtist[MAX_CHAR];
    char bufferAlbum[MAX_CHAR];
    int bufferMin;
    int bufferSec;

    in.open(filename);

    //protect against failed input
    if(!in) {
        cerr << "File input failed. Cannot read :" << filename << endl;
        exit(1); //abort program
    }
    //read in info from file
    in.get(bufferTitle, MAX_CHAR, ';'); //read in first title
    
    while(!in.eof()) { //until end of file     
        Song thisSong; //create song object

        //read in each song attribute
        in.get(); //remove delimiter char (;)
        in >> bufferMin; 

        in.get();
        in >> bufferSec;

        in.get();
        in.get(bufferArtist, MAX_CHAR, ';');

        in.get();
        in.get(bufferAlbum, MAX_CHAR, '\n');
        in.ignore(MAX_CHAR, '\n'); //remove '\n'

        //copy attributes to object
        thisSong.setTitle(bufferTitle);
        thisSong.setMin(bufferMin);
        thisSong.setSec(bufferSec);
        thisSong.setArtist(bufferArtist);
        thisSong.setAlbum(bufferAlbum);
     
        ///add each song to the array (SongList class instance)
        SongList::addSong(thisSong, size);
      
        in.get(bufferTitle, MAX_CHAR, ';'); //start next iteration 
        }
    in.close();
}

//save to .txt file
void SongList::saveSongs(int size, const char filename[]) { 
    ofstream out; 
    out.open(filename); 
    if(!out) { 
        cerr << "File output failed. Cannot write to: " << filename << endl; 
        exit(1); 
    }  

    //write songs to .txt file with delimeter ";"
    for(int i=0; i<size; i++) { 

        //temp variables for data copy
        char tempTitle[MAX_CHAR];
        char tempArtist[MAX_CHAR];
        char tempAlbum[MAX_CHAR];

        //store char arrays in temp variables
        songlist[i].getTitle(tempTitle);
        songlist[i].getArtist(tempArtist); 
        songlist[i].getAlbum(tempAlbum);

        //write song data to text file
        out << tempTitle << ";" 
        << songlist[i].getMin() << ";" 
        << songlist[i].getSec() << ";" 
        << tempArtist << ";" 
        << tempTitle << endl; 
    } 
    out.close(); 
};


/* ARRAY FUNCTIONS */
//these functions manitpulate the dynamic array songlist

//add Song struct to songlist
void SongList::addSong( Song& aSong, int& size) {

    //temp variables for data copy
    char bufferTitle[MAX_CHAR];
    char bufferArtist[MAX_CHAR];
    char bufferAlbum[MAX_CHAR];
    
    //store char arrays in temp variables
    aSong.getTitle(bufferTitle);
    aSong.getArtist(bufferArtist);
    aSong.getAlbum(bufferAlbum);
   
    //write song data to new songlist item
    songlist[size].setTitle(bufferTitle);    
    songlist[size].setArtist(bufferArtist);
    songlist[size].setAlbum(bufferAlbum);
    songlist[size].setMin(aSong.getMin());
    songlist[size].setSec(aSong.getSec());
    
    //increment size 
    size++;
}


//print all songs with information and indices
void SongList::listAll(int size) {
    
    //loop through each song and call print function
    for(int i=0; i<size; i++) {
        printSong(songlist[i], i+1);
    }
    
}

//search by artist
void SongList::search(char artistName[], int size) {
    
   //song by artist not yet found   
   bool found = false;
   
   //loop through each song 
   for(int i=0; i<size; i++) {
        
        char tempArtist[MAX_CHAR];
        songlist[i].getArtist(tempArtist);

        //compare artist to search key
        if( strcmp(artistName, tempArtist) == 0 ) { 
            printSong(songlist[i], i+1);
            found = true;
        }
    }
    if(!found) {
      cout << "No matching artist (input is case sensitive)";
    }
}

//remove a song
void SongList::rmSong(int index, int& size) {

    //loop through songs, starting at song to be deleted
    for(int i=(index-1); i<(size-1); i++) {

         //temp variables for data copy
         char bufferTitle[MAX_CHAR];
         char bufferArtist[MAX_CHAR];
         char bufferAlbum[MAX_CHAR];

         //get data from next song 
	 int nextSong = i+1;
	 songlist[nextSong].getTitle(bufferTitle);
         songlist[nextSong].getArtist(bufferArtist);
         songlist[nextSong].getAlbum(bufferAlbum);
         
	 //update song with data from next song
         songlist[i].setTitle(bufferTitle);
         songlist[i].setArtist(bufferArtist);
         songlist[i].setAlbum(bufferAlbum);
         songlist[i].setMin(songlist[nextSong].getMin());
         songlist[i].setSec(songlist[nextSong].getSec());
             
    }
    //update the size counter
    size--;
}


/* SONG STRUCT FUNCTIONS */
//these function use the Song struct, but  do not access songlist[]

//read in a new song
void SongList::readInSong(Song& thisSong) {

    //temp variables to store input data
    char tempTitle[MAX_CHAR];
    char tempArtist[MAX_CHAR];
    char tempAlbum[MAX_CHAR];
    int tempMin;
    int tempSec;

    //song title
    cout << "Enter Song title: ";
    getString(tempTitle, MAX_CHAR);
    thisSong.setTitle(tempTitle);

    //duration
    cout << "Please enter song duration (minutes): ";
    tempMin = getInt();
    thisSong.setMin(tempMin);

    cout << "Please enter song duration (seconds): ";
    tempSec = getInt();
    thisSong.setSec(tempSec);

    //additional info
    cout << "Enter Artist: ";
    getString(tempArtist, MAX_CHAR);
    thisSong.setArtist(tempArtist);

    cout << "Enter Album: ";
    getString(tempAlbum, MAX_CHAR);
    thisSong.setAlbum(tempAlbum);
}

//read in artist for search
void SongList::readInArtist(char artistName[]) {
    cout << "Enter Artist Name: ";
    getString(artistName, MAX_CHAR);
}

//read in index for remove 
void SongList::readInIndex(int& index, int size) {
    cout << "Enter index of song you would like to delete: ";
    index = getInt();

    //index too big?
    if(index > size) {
        cout << "Index out of bounds. ";
        readInIndex(index, size);
    }

    //index too small?
    if(index < 1) {
        cout << "Index out of bounds. ";
        readInIndex(index, size);
    }
}

//print all information for one song
void SongList::printSong(Song& aSong, int index) {
    
    //temp variables for data copy
    char tempTitle[MAX_CHAR];
    char tempArtist[MAX_CHAR];
    char tempAlbum[MAX_CHAR];

    //get song data
    aSong.getTitle(tempTitle);
    aSong.getArtist(tempArtist);
    aSong.getAlbum(tempAlbum);
    
    //print seconds with leading zero if < 10
    char secDisplay[MAX_CHAR] = "";
    if (aSong.getSec() < 10) {
        strcpy(secDisplay, "0");
    } 
    
    //print song
    cout << index << ". " <<  tempTitle
        << ", Duration: " << aSong.getMin() << "." << secDisplay << aSong.getSec()
        << ", Artist: " << tempArtist
        << ", Album: " << tempAlbum << endl;
}


/* DATA VALIDATION */
//input utility functions

//integer input 
int SongList::getInt() {
    int num;
    cin >> num;
    
    //check for type error
    while(!cin) {
        cin.clear();
        cin.ignore(MAX_CHAR, '\n');
        cout << "Illegal Input. Enter an Integer: ";
        num = getInt(); //recursive call
    }
    cin.ignore(MAX_CHAR, '\n');
        
    //check for negative input
    if(num < 0) {
        cout << "Please enter a positive integer: ";
        num = getInt();
    }
    return num;
}

//character input
char SongList::getChar() {
    char letter;
    cin >> letter;

    //check for type error
    while(!cin) {
        cin.clear();
        cin.ignore(MAX_CHAR, '\n');
        cout << "Illegal Input. Enter a Char: ";
        cin >> letter;
    }
    cin.ignore(MAX_CHAR, '\n');
    return letter;
}

//char array input
void SongList::getString(char str[], int maxChar) {
    cin.get(str, MAX_CHAR, '\n');

    //check for bad string
    while(!cin) {
        cin.clear();
        cin.ignore(maxChar, '\n');
        cout << "Illegal Input. Enter a String: ";
        cin.get(str, maxChar, '\n');
    }
    cin.ignore(MAX_CHAR, '\n');
}
